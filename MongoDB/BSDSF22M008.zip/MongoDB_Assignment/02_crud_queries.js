// Create Operations

// B1: Vendor adds a new book
db.books.insertOne({
  title: "Neural Networks for Beginners",
  subtitle: "An Easy Introduction",
  authors: ["Alex Smith"],
  publisher: "TechPress",
  publishedYear: 2023,
  categories: ["AI"],
  price: 50,
  currency: "USD",
  isbn13: "9781234567890",
  pages: 280,
  language: "English",
  vendorId: ObjectId("692152b5e6f59d632a63b11f"), 
  tags: ["ai", "neural networks"],
  stock: 15,
  description: "A beginner-friendly introduction to neural networks."
});

// B2: Register user with 2 addresses
db.users.insertOne({
  name: "Kamran Ali",
  email: "kamran@example.com",
  phone: "03001239888",
  role: "customer",
  addresses: [
    { label: "Home", city: "Lahore", street: "Model Town" },
    { label: "Office", city: "Lahore", street: "Gulberg III" }
  ],
  createdAt: new Date()
});

// B3: Bulk insert 10 books for a vendor
db.books.insertMany(
  Array.from({ length: 10 }).map((_, i) => ({
    title: "Vendor Special Book " + (i + 1),
    authors: ["Author X"],
    publisher: "Special Publisher",
    publishedYear: 2022,
    categories: ["Programming"],
    price: 20 + i,
    currency: "USD",
    vendorId: ObjectId("692152b5e6f59d632a63b11f"),
    stock: 10 + i,
    tags: ["vendor-special"],
    description: "Auto-generated vendor book."
  }))
);
 

// -----------------------------------------------

// READ OPERATIONS

// B4: Filter Data Science books priced 20–60
db.books.find(
  {
    categories: "Data Science",
    price: { $gte: 20, $lte: 60 }
  },
  {
    title: 1,
    price: 1,
    vendorId: 1
  }
).sort({ price: 1 });


// B5: Newest 5 books with stock > 0
db.books.find(
  { stock: { $gt: 0 } }
).sort({ publishedYear: -1 }).limit(5);


// B6: Last 3 orders for a user
db.orders.find(
  { userId: ObjectId("REPLACE_USER_ID") },
  {
    status: 1,
    createdAt: 1,
    itemCount: { $size: "$items" }
  }
).sort({ createdAt: -1 }).limit(3);


// UPDATE OPERATIONS


// B7: Raise prices by 5%
db.books.updateMany(
  { publisher: "Publisher 1", price: { $lt: 25 } },
  { $mul: { price: 1.05 } }
);


// B8: Upsert review
db.reviews.updateOne(
  {
    userId: ObjectId("REPLACE_USER_ID"),
    bookId: ObjectId("REPLACE_BOOK_ID")
  },
  {
    $set: {
      rating: 4,
      body: "Updated review body",
      createdAt: new Date()
    }
  },
  { upsert: true }
);


// B9: Normalize city names
db.users.updateMany(
  {},
  { $set: { "addresses.$[home].city": "Lahore City" } },
  {
    arrayFilters: [
      { "home.label": "Home", "home.city": "Lahore" }
    ]
  }
);



// Delete Operations

// B10: Delete orphan reviews (bookId not in books)
db.reviews.deleteMany({
  bookId: { $nin: db.books.distinct("_id") }
});


// B11: Delete vendors with status SUSPENDED and no books
db.vendors.deleteMany({
  status: "SUSPENDED",
  _id: { $nin: db.books.distinct("vendorId") }
});


// B12: Delete sessions older than 7 days
db.sessions.deleteMany({
  createdAt: { $lt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
});
