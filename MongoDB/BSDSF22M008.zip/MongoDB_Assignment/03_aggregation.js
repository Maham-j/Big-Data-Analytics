// C1: Monthly sales by category (last 6 months)
db.orders.aggregate([
  // Stage 1: Filter last 6 months
  {
    $match: {
      createdAt: {
        $gte: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000)
      }
    }
  },

  // Stage 2: Expand items array
  { $unwind: "$items" },

  // Stage 3: Join with books to get categories
  {
    $lookup: {
      from: "books",
      localField: "items.bookId",
      foreignField: "_id",
      as: "book"
    }
  },

  // Stage 4: Flatten the joined array
  { $unwind: "$book" },

  // Stage 5: Expand categories
  { $unwind: "$book.categories" },

  // Stage 6: Group by month + category
  {
    $group: {
      _id: {
        month: { $month: "$createdAt" },
        category: "$book.categories"
      },
      totalRevenue: {
        $sum: { $multiply: ["$items.qty", "$items.priceAtPurchase"] }
      }
    }
  }
]);


// Rationale: Computes revenue per category for each month by joining orders with books and unrolling arrays.

// ----------------------


// C2: Top 10 best-selling books
db.orders.aggregate([
  // Stage 1: Expand items
  { $unwind: "$items" },

  // Stage 2: Group by bookId
  {
    $group: {
      _id: "$items.bookId",
      totalQty: { $sum: "$items.qty" },
      totalRevenue: {
        $sum: { $multiply: ["$items.qty", "$items.priceAtPurchase"] }
      }
    }
  },

  // Stage 3: Join with books for title
  {
    $lookup: {
      from: "books",
      localField: "_id",
      foreignField: "_id",
      as: "book"
    }
  },
  { $unwind: "$book" },

  // Stage 4: Sort + limit
  { $sort: { totalQty: -1 } },
  { $limit: 10 },

  // Stage 5: Final projection
  {
    $project: {
      bookId: "$_id",
      title: "$book.title",
      totalQty: 1,
      totalRevenue: 1
    }
  }
]);
 

// Rationale:Ranks books by quantity sold and includes revenue.

// -----------------------------------

// C4: Vendor dashboard using $facet
const vendorId = ObjectId("692152b5e6f59d632a63b11e");

db.books.aggregate([
  // Stage 1: Match vendor
  { $match: { vendorId: vendorId } },

  {
    $facet: {
      // Total revenue in last 30 days
      salesLast30d: [
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "items.bookId",
            as: "orders"
          }
        },
        { $unwind: "$orders" },
        {
          $match: {
            "orders.createdAt": {
              $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
            }
          }
        },
        { $unwind: "$orders.items" },
        {
          $group: {
            _id: null,
            revenue: {
              $sum: {
                $multiply: ["$orders.items.qty", "$orders.items.priceAtPurchase"]
              }
            }
          }
        }
      ],

      // Average delivery days
      avgDeliveryDays: [
        {
          $lookup: {
            from: "orders",
            localField: "_id",
            foreignField: "items.bookId",
            as: "orders"
          }
        },
        { $unwind: "$orders" },
        { $match: { "orders.status": "DELIVERED" } },
        {
          $project: {
            days: {
              $divide: [
                { $subtract: ["$orders.deliveredAt", "$orders.createdAt"] },
                1000 * 60 * 60 * 24
              ]
            }
          }
        },
        { $group: { _id: null, avgDays: { $avg: "$days" } } }
      ],

      // Low stock count
      lowStockCount: [
        { $match: { stock: { $lt: 5 } } },
        { $count: "count" }
      ]
    }
  }
]);
 

// Rationale: One query provides 3 dashboards: revenue, delivery time, low-stock items.


// ------------------------


// C5: Ratings by category (Universal version)

// Step 1: Join books
db.reviews.aggregate([
  {
    $lookup: {
      from: "books",
      localField: "bookId",
      foreignField: "_id",
      as: "book"
    }
  },
  { $unwind: "$book" },
  { $unwind: "$book.categories" },

  // Step 2: Group ratings per category
  {
    $group: {
      _id: "$book.categories",
      avgRating: { $avg: "$rating" },
      ratings: { $push: "$rating" }
    }
  },

  // Step 3: Unwind ratings so we can sort them
  { $unwind: "$ratings" },

  // Step 4: Sort ratings ascending
  { $sort: { ratings: 1 } },

  // Step 5: Regroup into sorted array
  {
    $group: {
      _id: "$_id",
      avgRating: { $first: "$avgRating" },
      sortedRatings: { $push: "$ratings" }
    }
  },

  // Step 6: Compute median manually
  {
    $project: {
      avgRating: 1,
      count: { $size: "$sortedRatings" },
      sortedRatings: 1
    }
  },
  {
    $project: {
      avgRating: 1,
      medianRating: {
        $let: {
          vars: {
            count: "$count",
            mid: { $floor: { $divide: ["$count", 2] } }
          },
          in: {
            $cond: [
              // Even count: avg of two middle
              { $eq: [{ $mod: ["$$count", 2] }, 0] },
              {
                $avg: [
                  { $arrayElemAt: ["$sortedRatings", { $subtract: ["$$mid", 1] }] },
                  { $arrayElemAt: ["$sortedRatings", "$$mid"] }
                ]
              },
              // Odd count: pick middle
              {
                $arrayElemAt: ["$sortedRatings", "$$mid"]
              }
            ]
          }
        }
      }
    }
  }
]);


 
// Rationale:Compute average + median rating per category.

// ----------------------------------

// C6: Author leaderboard with revenue ranking
db.orders.aggregate([
  { $unwind: "$items" },

  // Join with books
  {
    $lookup: {
      from: "books",
      localField: "items.bookId",
      foreignField: "_id",
      as: "book"
    }
  },
  { $unwind: "$book" },

  // Filter for category Programming
  { $match: { "book.categories": "Programming" } },

  // Stage 5: Group by author
  {
    $group: {
      _id: "$book.authors",
      totalRevenue: {
        $sum: { $multiply: ["$items.qty", "$items.priceAtPurchase"] }
      }
    }
  },

  // Stage 6: Apply ranking
  {
    $setWindowFields: {
      sortBy: { totalRevenue: -1 },
      output: {
        rank: { $rank: {} }
      }
    }
  }
]);
 
// Rationale:Ranks authors by revenue using window functions.

// -------------------------------

// C7: 60-day cohort retention
db.orders.aggregate([
  // Stage 1: Sort orders by user → date
  { $sort: { userId: 1, createdAt: 1 } },

  // Stage 2: Group first order per user
  {
    $group: {
      _id: "$userId",
      firstOrderDate: { $first: "$createdAt" },
      allOrders: { $push: "$createdAt" }
    }
  },

  // Stage 3: Compute retention
  {
    $project: {
      cohortMonth: { $month: "$firstOrderDate" },
      retained: {
        $size: {
          $filter: {
            input: "$allOrders",
            as: "d",
            cond: {
              $and: [
                { $gt: ["$$d", "$firstOrderDate"] },
                { $lte: ["$$d", new Date(Date.now() + 60 * 24 * 60 * 60 * 1000)] }
              ]
            }
          }
        }
      }
    }
  },

  // Stage 4: Group by cohort
  {
    $group: {
      _id: "$cohortMonth",
      users: { $sum: 1 },
      retainedUsers: { $sum: { $cond: [{ $gt: ["$retained", 0] }, 1, 0] } }
    }
  },

  // Stage 5: Compute rate
  {
    $project: {
      retentionRate: {
        $divide: ["$retainedUsers", "$users"]
      }
    }
  }
]);

// Rationale: Tracks user retention within 60 days of first order.

// ------------------------------------------

// C8: Inventory mismatches
db.books.aggregate([
  {
    $lookup: {
      from: "inventory_logs",
      localField: "_id",
      foreignField: "bookId",
      as: "logs"
    }
  },

  { $unwind: "$logs" },

  // Group to compute total delta
  {
    $group: {
      _id: "$_id",
      title: { $first: "$title" },
      stock: { $first: "$stock" },
      totalDelta: { $sum: "$logs.delta" }
    }
  },

  // Compute difference
  {
    $project: {
      title: 1,
      stock: 1,
      totalDelta: 1,
      difference: { $subtract: ["$stock", "$totalDelta"] }
    }
  },

  // Report mismatches only
  { $match: { difference: { $ne: 0 } } }
]);


// Rationale: Detects cases where inventory_log totals do not match actual book stock.

// --------------------------------------

// C9: Price buckets with average rating
db.books.aggregate([
  // Stage 1: Join reviews
  {
    $lookup: {
      from: "reviews",
      localField: "_id",
      foreignField: "bookId",
      as: "reviews"
    }
  },

  // Stage 2: Define bucket ranges
  {
    $bucket: {
      groupBy: "$price",
      boundaries: [0, 10, 25, 50, 100],
      default: ">100",
      output: {
        count: { $sum: 1 },
        avgRating: { $avg: "$reviews.rating" }
      }
    }
  }
]);


// Rationale:Groups books by price ranges and calculates average rating.

// ---------------------------------------

// C10: Text search with recency sorting
db.books.createIndex({ title: "text", subtitle: "text", description: "text" });

// Query for C10
db.books.aggregate([
  {
    $match: {
      $text: { $search: "machine learning deep learning" }
    }
  },
  {
    $addFields: {
      score: { $meta: "textScore" }
    }
  },
  { $sort: { score: -1, publishedYear: -1 } },
  { $limit: 10 }
]);


// Rationale:Uses textScore + publishedYear for relevance + recency ranking.


// -------------------------------------------------------------------------------------------------------
