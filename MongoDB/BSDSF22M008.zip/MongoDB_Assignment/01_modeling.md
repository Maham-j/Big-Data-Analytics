## Step A1 — Creating Base Collections

## Commands Used
use bookbazaar_db
db.createCollection("users")
db.createCollection("vendors")
db.createCollection("books")
db.createCollection("orders")
db.createCollection("reviews")
db.createCollection("inventory_logs")
db.createCollection("sessions")
show collections


## Books Validator
db.runCommand({
  collMod: "books",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["title", "price", "vendorId", "stock", "authors"],
      properties: {
        title: { bsonType: "string" },
        price: { bsonType: "number", description: "Price must be a number" },
        vendorId: { bsonType: "objectId" },
        stock: { bsonType: "int", minimum: 0 },
        authors: {
          bsonType: "array",
          minItems: 1,
          items: { bsonType: "string" }
        }
      }
    }
  }
});

## Reviews Validator
db.runCommand({
  collMod: "reviews",
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["bookId", "userId", "rating"],
      properties: {
        bookId: { bsonType: "objectId" },
        userId: { bsonType: "objectId" },
        rating: {
          bsonType: "int",
          minimum: 1,
          maximum: 5
        },
        title: { bsonType: "string" },
        body: { bsonType: "string" }
      }
    }
  }
});

## Sample Valid Insert
db.books.insertOne({
  title: "Machine Learning Essentials",
  price: 40,
  vendorId: ObjectId(),
  stock: 10,
  authors: ["John Doe"]
});

## Sample Invalid Insert + Error Message
db.books.insertOne({
  title: "Invalid Book"
});

## for reviews invalid insert
db.reviews.insertOne({
  rating: 10
});

## Step A3 — Inserting Test Documents
# Inserted 5 sample documents in each collection

# Users
db.users.insertMany([
  {
    name: "Ali Raza",
    email: "ali@example.com",
    phone: "03001234567",
    role: "customer",
    addresses: [
      { label: "Home", city: "Lahore", street: "Johar Town" }
    ],
    createdAt: ISODate()
  },
  {
    name: "Sara Khan",
    email: "sara@example.com",
    phone: "03007654321",
    role: "customer",
    addresses: [
      { label: "Home", city: "Karachi", street: "DHA Phase 4" }
    ],
    createdAt: ISODate()
  },
  {
    name: "Bilal Ahmed",
    email: "bilal@example.com",
    phone: "03005556677",
    role: "vendor",
    addresses: [],
    createdAt: ISODate()
  },
  {
    name: "Hina Shaikh",
    email: "hina@example.com",
    phone: "03009998877",
    role: "customer",
    addresses: [],
    createdAt: ISODate()
  },
  {
    name: "Admin User",
    email: "admin@example.com",
    phone: "03009990000",
    role: "admin",
    addresses: [],
    createdAt: ISODate()
  }
]);

# Vendors
db.vendors.insertMany([
  {
    name: "TechBooks Store",
    legalName: "TechBooks Pvt Ltd",
    city: "Lahore",
    tags: ["tech", "programming"],
    rating: 4.6,
    status: "ACTIVE",
    createdAt: ISODate()
  },
  {
    name: "Readers Hub",
    legalName: "Readers Hub Co",
    city: "Karachi",
    tags: ["fiction", "romance"],
    rating: 4.2,
    status: "ACTIVE",
    createdAt: ISODate()
  },
  {
    name: "Science Depot",
    legalName: "Science Depot Ltd",
    city: "Islamabad",
    tags: ["science", "research"],
    rating: 4.8,
    status: "ACTIVE",
    createdAt: ISODate()
  },
  {
    name: "Book World",
    legalName: "Book World Co",
    city: "Multan",
    tags: ["general"],
    rating: 4.1,
    status: "SUSPENDED",
    createdAt: ISODate()
  },
  {
    name: "Student Station",
    legalName: "Student Station Pvt Ltd",
    city: "Faisalabad",
    tags: ["education", "textbooks"],
    rating: 4.3,
    status: "ACTIVE",
    createdAt: ISODate()
  }
]);

# Books
db.books.insertMany([
  {
    title: "Introduction to Machine Learning",
    authors: ["Tom Mitchell"],
    price: 45,
    vendorId: ObjectId(),   // Replace with actual vendor ID
    stock: 20,
    categories: ["Data Science"],
    publisher: "McGraw Hill",
    publishedYear: 2019,
    tags: ["ml", "ai"],
    pages: 350,
    language: "English"
  },
  {
    title: "Deep Learning with Python",
    authors: ["François Chollet"],
    price: 55,
    vendorId: ObjectId(),
    stock: 15,
    categories: ["AI", "Programming"],
    publisher: "Manning",
    publishedYear: 2021,
    tags: ["deep learning"],
    pages: 380,
    language: "English"
  },
  {
    title: "Data Science Essentials",
    authors: ["Jake Brown"],
    price: 35,
    vendorId: ObjectId(),
    stock: 10,
    categories: ["Data Science"],
    publishedYear: 2020
  },
  {
    title: "Learning JavaScript",
    authors: ["Mark Ethan"],
    price: 18,
    vendorId: ObjectId(),
    stock: 25,
    categories: ["Programming"],
    publishedYear: 2017
  },
  {
    title: "Statistics for Beginners",
    authors: ["S. Khan"],
    price: 22,
    vendorId: ObjectId(),
    stock: 30,
    categories: ["Education"],
    publishedYear: 2016
  }
]);

# Validation testing on books (Invalid)
db.books.insertOne({
  title: "Invalid Book",  // missing authors, vendorId, stock
  price: 10
});

# Orders
db.orders.insertMany([
  {
    userId: ObjectId(),
    items: [
      { bookId: ObjectId(), qty: 1, priceAtPurchase: 45 }
    ],
    status: "PLACED",
    shippingAddress: "Lahore",
    payment: { method: "COD" },
    createdAt: ISODate()
  },
  {
    userId: ObjectId(),
    items: [
      { bookId: ObjectId(), qty: 2, priceAtPurchase: 55 }
    ],
    status: "PAID",
    payment: { method: "CARD" },
    createdAt: ISODate()
  },
  {
    userId: ObjectId(),
    items: [
      { bookId: ObjectId(), qty: 1, priceAtPurchase: 35 }
    ],
    status: "DELIVERED",
    deliveredAt: ISODate(),
    createdAt: ISODate()
  },
  {
    userId: ObjectId(),
    items: [
      { bookId: ObjectId(), qty: 3, priceAtPurchase: 18 }
    ],
    status: "SHIPPED",
    createdAt: ISODate()
  },
  {
    userId: ObjectId(),
    items: [
      { bookId: ObjectId(), qty: 1, priceAtPurchase: 22 }
    ],
    status: "CANCELLED",
    createdAt: ISODate()
  }
]);

# Reviews
db.reviews.insertMany([
  {
    bookId: ObjectId(),
    userId: ObjectId(),
    rating: 5,
    title: "Excellent Book!",
    body: "Very helpful and well-written.",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    userId: ObjectId(),
    rating: 4,
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    userId: ObjectId(),
    rating: 3,
    title: "Good",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    userId: ObjectId(),
    rating: 5,
    body: "Loved it!",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    userId: ObjectId(),
    rating: 2,
    createdAt: ISODate()
  }
]);


# Invalid review insertion to test validator
db.reviews.insertOne({
  rating: 10
});


# Inventory Logs
db.inventory_logs.insertMany([
  {
    bookId: ObjectId(),
    vendorId: ObjectId(),
    delta: +10,
    reason: "restock",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    vendorId: ObjectId(),
    delta: -1,
    reason: "sale",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    vendorId: ObjectId(),
    delta: +5,
    reason: "restock",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    vendorId: ObjectId(),
    delta: -2,
    reason: "sale",
    createdAt: ISODate()
  },
  {
    bookId: ObjectId(),
    vendorId: ObjectId(),
    delta: +3,
    reason: "adjustment",
    createdAt: ISODate()
  }
]);


# Sessions
db.sessions.insertMany([
  { userId: ObjectId(), token: "t1", createdAt: ISODate() },
  { userId: ObjectId(), token: "t2", createdAt: ISODate() },
  { userId: ObjectId(), token: "t3", createdAt: ISODate() },
  { userId: ObjectId(), token: "t4", createdAt: ISODate() },
  { userId: ObjectId(), token: "t5", createdAt: ISODate() }
]);

## Step A4 — Bulk Seeding
- Created a bulk seed script (bulk_seed.js)
- Ran it using mongosh bulk_seed.js
- Inserted: 12 users, 5 vendors, 60 books, 80 orders, 120 reviews, 150 inventory logs, 10 sessions.

Screenshots:
- /screenshots/bulk_seed_run.png
- /screenshots/bulk_collection_counts.png