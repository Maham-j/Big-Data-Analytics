// books collection
use("bookbazaar_db");

// Category index
db.books.createIndex({ categories: 1 });

// Vendor index
db.books.createIndex({ vendorId: 1 });

// Text search index (for Part C10)
db.books.createIndex({
  title: "text",
  subtitle: "text",
  description: "text"
});


// ------------------------------------------------


// orders collectoin

// Query by user
db.orders.createIndex({ userId: 1 });

// Query by date
db.orders.createIndex({ createdAt: -1 });

// items.bookId (multikey index)
db.orders.createIndex({ "items.bookId": 1 });

// ------------------------------------------------

// reviews
db.reviews.createIndex({ bookId: 1 });

// ------------------------------------------------

// inventory logs
db.inventory_logs.createIndex({ bookId: 1 });

// ------------------------------------------------

// users
db.users.createIndex({ email: 1 }, { unique: true });


// ------------------------------------------------
// sessions (TTL index)
db.sessions.createIndex(
  { createdAt: 1 },
  { expireAfterSeconds: 7 * 24 * 60 * 60 }  // 7 days
);
