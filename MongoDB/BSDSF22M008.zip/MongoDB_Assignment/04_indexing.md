| Collection         | Field(s)                       | Index Type       |Reason                                         |
| ------------------ | ------------------------------ | ------------------ | -----------------------------------------   |
| **books**          | `categories`                   | Single-field index | Speeds up filtering by category (e.g., B4, C1) |
| **books**          | `title, subtitle, description` | Text Index         | Enables text search (C10)                      |
| **books**          | `vendorId`                     | Single-field index | Vendor dashboard queries (C4)                 |
| **orders**         | `userId`                       | Single-field index | Fetch recent orders of a user (B6)             |
| **orders**         | `items.bookId`                 | Multikey index     | Used in C1, C2, C3 (joins and best-sellers)    |
| **orders**         | `createdAt`                    | Single-field index | Sorting by time (C1, C4)                       |
| **reviews**        | `bookId`                       | Single-field index | Rating aggregations (C5)                       |
| **inventory_logs** | `bookId`                       | Single-field index | Used in C8 (stock check)                       |
| **sessions**       | `createdAt`                    | TTL index          | Auto-delete sessions after 7 days              |
| **users**          | `email`                        | Unique index       | Prevent duplicate registrations                |
